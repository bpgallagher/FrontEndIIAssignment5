var user;

// Initialize Firebase
// Brian's config
var config = {
    apiKey: "AIzaSyDwaO2i8OXfLhNKATNUjytqmCjbOxpGddo",
    authDomain: "todo-5876b.firebaseapp.com",
    databaseURL: "https://todo-5876b.firebaseio.com",
    projectId: "todo-5876b",
    storageBucket: "todo-5876b.appspot.com",
    messagingSenderId: "520993363555",
    appId: "1:520993363555:web:f7908b3b625ef8506d8a56",
    measurementId: "G-TJ1P5RB6F2"
};

/*
var config = {
  apiKey: "AIzaSyAjUoU0EVknbQOmBcVBEihfPOruMWEfEC4",
  authDomain: "fhsu-1554224408642.firebaseapp.com",
  databaseURL: "https://fhsu-1554224408642.firebaseio.com",
  projectId: "fhsu-1554224408642",
  storageBucket: "fhsu-1554224408642.appspot.com",
  messagingSenderId: "83551100344",
};
*/

// step 1
firebase.initializeApp(config);
firebase.analytics();
var auth = firebase.auth();
var db = firebase.firestore();

$(document).on("submit", "#contact-form", function (event) {
    event.preventDefault();
    // Add a new document in collection "cities"
    db.collection("contacts")
        .doc()
        .set({
            email: $(this).find("input[name=email]").val(),
            first_name: $(this).find("input[name=first_name]").val(),
            last_name: $(this).find("input[name=last_name]").val(),
        })
        .then(function () {
            console.log("Document successfully written!");
        })
        .catch(function (error) {
            console.error("Error writing document: ", error);
        });
    //console.log($(this).find("input[name=email]").val());
    //console.log($(this).find("input[name=first_name]").val());
    //console.log($(this).find("input[name=last_name]").val());

    var docRef = db.collection("contacts").doc("CFtpiNaGpMbY8LKC8TcU");

    docRef
        .get()
        .then(function (doc) {
            if (doc.exists) {
                console.log("Document data:", doc.data());
            } else {
                // doc.data() will be undefined in this case
                console.log("No such document!");
            }
        })
        .catch(function (error) {
            console.log("Error getting document:", error);
        });
});

var contactRef = db.collection("contacts");
contactRef.where("email", "==", "test@gmail.com");
contactRef.get().then(function (querySnapshot) {
    if (querySnapshot.size > 0) {
        console.log(querySnapshot.docs[0].data());
    } else console.log("no records found");
});


$(document).on("submit", "#form-signup", function (event) {
    event.preventDefault();
    // step 2
    var promise = auth.createUserWithEmailAndPassword(
        $("#signup_email").val(),
        $("#signup_password").val()
    );
    promise.catch((e) => {
        $("#alert-signup").text(e.message);
        $("#alert-signup").show();
        console.log(e.message);
    });
});

$(document).on("submit", "#form-signin", function (event) {
    event.preventDefault();
    var promise = auth.signInWithEmailAndPassword(
        $("#signin_email").val(),
        $("#signin_password").val()
    );
    console.log(promise);

    promise.catch((e) => {
        console.log(e.message);
        $("#alert-signin").text(e.message);
        $("#alert-signin").show();
    });
});

$(document).on("click", "#signout", function (event) {
    event.preventDefault();
    var promise = auth.signOut();
    promise.catch((e) => {
        console.log(e.message);
        location.replace("login.html");
    });
});

auth.onAuthStateChanged((firebaseUser) => {
    if (firebaseUser) {
        console.log(firebaseUser);
        user = firebaseUser;
    } else {
        user = null;
        console.log("not logged in");
    }
});
